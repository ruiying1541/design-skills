---
name: "designai-infographic-image"
description: "输入文字内容或结构化数据，自动完成信息提炼、逻辑排版与视觉设计，生成清晰美观的信息图。"
---

# 信息图生成

## 是什么

信息图生成 Skill 可以把文字、网页、文档或结构化数据转化为精美的信息图。它会先提炼核心信息，再组织逻辑层级，最后完成视觉排版。

## 适用场景

- 周报、趋势报告、资讯内容可视化
- 产品说明、流程说明、知识卡片
- 社媒传播长图、知识科普图
- 将复杂文本压缩成易读结构

## 测试指令

```text
把这篇 AI 设计资讯周刊做成一张信息图
```

```text
把一篇关于 Apple Watch 设计分析的文章转成信息图
```

## 安装链接

[安装 designai-infographic-image](https://myflicker.corp.kuaishou.com/skillhub/skills?skillId=designai-infographic-image)

## 测试案例与效果图

| 测试指令 | 效果图 |
| --- | --- |
| [AI设计资讯周刊（2026.06.10-06.16）【Vol.04】](https://docs.corp.kuaishou.com/d/home/fcAC1ITmDPMzV24WjYTkHkwPL?source=feed) | ![AI 设计资讯周刊信息图](/design-skills/skill-assets/图片-36a7a910.png) |
| [大厂八卦日报——第71期](https://docs.corp.kuaishou.com/k/home/VK245efSlT5s/fcADXnsUduBuPgh7Ex205c43B) | ![大厂八卦日报信息图](/design-skills/skill-assets/图片-230e5e6c.png) |
| [从设计师视角聊聊 Apple Watch](https://docs.corp.kuaishou.com/k/home/Vflxz_0I3rCA/fcADgRjt8YNkPFobdf6L7tc0Q) | ![Apple Watch 设计分析信息图](/design-skills/skill-assets/图片-45bb2dee.png) |
