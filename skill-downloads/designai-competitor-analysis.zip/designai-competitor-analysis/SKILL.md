---
name: "designai-competitor-analysis"
description: "输入竞品信息，从功能、体验、视觉、内容策略等多个维度进行系统性拆解，生成结构清晰的分析报告。"
---

# 竞品分析

## 是什么

竞品分析 Skill 可以根据竞品信息进行系统拆解，覆盖功能结构、交互体验、视觉表现、内容策略和商业目标等维度，帮助设计师快速形成洞察。

## 适用场景

- 新产品立项前的竞品调研
- 功能改版前的对标分析
- 视觉风格、信息架构、交互路径对比
- 输出机会点和设计建议

## 测试指令

```text
飞程出行 vs 闪行科技（两个虚构的打车平台），生成完整的五要素分析报告
```

## 安装链接

[安装 designai-competitor-analysis](https://myflicker.corp.kuaishou.com/skillhub/skills?skillId=designai-competitor-analysis)

## 测试案例与效果图

| 测试指令 | 效果图 |
| --- | --- |
| 飞程出行 vs 闪行科技（两个虚构的打车平台），生成完整的五要素分析报告 | 文档暂无效果图 |
