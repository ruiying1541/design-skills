---
name: "designai-image-expansion"
description: "基于 AI 理解图像内容与场景逻辑，智能补全画面边缘，将原图扩展为任意所需比例并自然融合。"
---

# 比例扩图

## 是什么

比例扩图 Skill 可以将原图扩展到不同画幅比例，例如 1:1、4:3、16:9、9:16。AI 会根据原始图像的场景和透视，补全边缘区域。

## 适用场景

- 运营 Banner 多尺寸适配
- 横图转竖图、竖图转横图
- 社媒封面、海报、信息流素材裁切补全
- 保持主体不变，扩展背景空间

## 测试指令

```text
把这张图片扩展成 16:9 横版，保持主体不变，背景自然补全
```

## 安装链接

[安装 designai-image-expansion](https://myflicker.corp.kuaishou.com/skillhub/skills?skillId=designai-image-expansion)

## 测试案例与效果图

| 测试指令 | 效果图 |
| --- | --- |
| ![原图](/design-skills/skill-assets/图片-5f312d27.jpg) | ![扩图结果](/design-skills/skill-assets/图片-43d14f36.png) |
| ![原图](/design-skills/skill-assets/图片-23aa8265.jpg) | ![扩图结果](/design-skills/skill-assets/图片-7d09c209.png) |
