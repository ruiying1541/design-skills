---
name: "design-ai-cutout"
description: "基于 AI 精准识别主体边缘，自动去除背景，输出透明底图像，支持发丝、毛发等复杂边缘细节。"
---

# 智能抠图

## 是什么

智能抠图 Skill 可以自动识别图片主体并移除背景，输出透明底图像。它适合商品图、人物图、素材图等高频设计处理场景。

## 适用场景

- 商品主图去背景
- 人物、宠物、物体抠图
- 为海报和 Banner 准备透明素材
- 对复杂边缘进行精细处理

## 测试指令

```text
帮我把这张人物图去掉背景，保留发丝细节，输出透明底图片
```

## 安装链接

[安装 design-ai-cutout](https://myflicker.corp.kuaishou.com/skillhub/skills?skillId=design-ai-cutout)

## 测试案例与效果图

| 测试指令 | 效果图 |
| --- | --- |
| ![输入图片](/design-skills/skill-assets/图片-01030c4d.png) | ![抠图结果](/design-skills/skill-assets/图片-9226c5aa.png) |
| ![输入图片](/design-skills/skill-assets/图片-5ad602da.png) | ![抠图结果](/design-skills/skill-assets/图片-73655319.png) |
