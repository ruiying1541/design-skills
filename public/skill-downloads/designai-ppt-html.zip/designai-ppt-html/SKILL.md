---
name: "designai-ppt-html"
description: "在图片模式基础上升级为 HTML 格式输出，生成的 PPT 支持在线演示、链接分享与内容编辑。"
---

# PPT HTML 生成

## 是什么

PPT HTML 生成 Skill 将演示稿输出为 HTML 页面，兼具演示、分享和后续编辑能力。相比图片模式，它更适合需要持续迭代或在线传播的汇报内容。

## 适用场景

- 在线路演、方案汇报、项目展示
- 需要链接分享的演示稿
- 需要后续修改文字或结构的 PPT
- 结合微动效提升演示体验

## 测试指令

```text
生成一套关于「设计系统升级方案」的 HTML 演示文稿
```

## 安装链接

[安装 designai-ppt-html](https://myflicker.corp.kuaishou.com/skillhub/skills?skillId=designai-ppt-html)

## 测试案例与效果图

| 测试指令 | 效果图 |
| --- | --- |
| 根据一个汇报主题生成可在线演示的 HTML PPT | 文档暂无效果图 |
