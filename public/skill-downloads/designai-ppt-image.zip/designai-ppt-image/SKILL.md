---
name: "designai-ppt-image"
description: "输入主题或核心内容，AI 自动生成排版、配色、结构完整的 PPT，并以图片形式输出。"
---

# PPT 图片生成

## 是什么

PPT 图片生成 Skill 面向快速汇报和视觉提案场景。输入主题、提纲或核心内容后，AI 会自动组织页面结构、选择配色和版式，并以图片形式输出整套 PPT。

## 适用场景

- 快速生成汇报初稿
- 主题分享、培训材料、项目复盘
- 需要视觉统一但不要求后续编辑的演示稿
- 将零散内容整理成结构化页面

## 测试指令

```text
生成一套关于「AI 设计工作流」的 6 页 PPT 图片
```

## 安装链接

[安装 designai-ppt-image](https://myflicker.corp.kuaishou.com/skillhub/skills?skillId=designai-ppt-image)

## 测试案例与效果图

| 测试指令 | 效果图 |
| --- | --- |
| 根据一个汇报主题生成完整 PPT 图片稿 | 文档暂无效果图 |
